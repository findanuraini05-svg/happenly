import { useState, useEffect } from "react";

const COLORS = {
  primary: "#5C3BFE",
  primaryLight: "#7B5EFF",
  primaryDark: "#4228D4",
  bg: "#F8F7FF",
  card: "#FFFFFF",
  text: "#1A1033",
  textMuted: "#7B7A8E",
  accent: "#FF6B6B",
  success: "#22C55E",
  surface: "#EEE9FF",
};

const events = [
  { id: 1, title: "Pamungkas Live in Jogja", category: "Konser", date: "24 Mei 2024 · Sabtu · 19.00 WIB", location: "Jogja Expo Center", address: "Jl. Raya Janti, Banguntapan, Jogja", price: "Rp150.000", distance: "2.5 km", image: "🎸", color: "#1A1033", saved: false, desc: "Konser tunggal Pamungkas di Jogja. Nikmati malam penuh musik dan cerita bersama Pamungkas.", organizer: "Pamungkas" },
  { id: 2, title: "Photo Walk on Malioboro", category: "Workshop", date: "25 Mei 2024 · 07.00 WIB", location: "Malioboro, Jogja", address: "Jalan Malioboro, Yogyakarta", price: "Gratis", distance: "1.2 km", image: "📸", color: "#2D4A3E", saved: false, desc: "Jalan-jalan sambil foto bareng komunitas fotografer lokal Jogja.", organizer: "Komunitas Foto Jogja" },
  { id: 3, title: "Soundrenaline 2024", category: "Festival", date: "27–28 Mei 2024", location: "Pantai Parang­tritis", address: "Parangtritis, Bantul, Jogja", price: "Rp250.000", distance: "18 km", image: "🎵", color: "#3D1A78", saved: true, desc: "Festival musik tahunan terbesar di pesisir selatan Jogja dengan puluhan artis.", organizer: "Deteksi Production" },
  { id: 4, title: "Jogja Book Club", category: "Komunitas", date: "Sab, 18 Mei 2024 · 16.00 WIB", location: "Kedai Kebun Forum", address: "Jl. Tirtodipuran No.3, Jogja", price: "Gratis", distance: "0.9 km", image: "📚", color: "#1C3A2D", saved: true, desc: "Diskusi buku bulanan komunitas literasi Jogja. Bulan ini: Novel terjemahan terbaru.", organizer: "Jogja Book Club" },
  { id: 5, title: "Good Vibes Festival", category: "Festival", date: "25 Mei 2024 · Pantai Parang­tritis", location: "Pantai Parang­tritis", address: "Parangtritis, Bantul", price: "Rp75.000", distance: "18 km", image: "🌊", color: "#1A3A5C", saved: false, desc: "Festival vibes positif di tepi pantai dengan musik, art, dan kuliner lokal.", organizer: "Good Vibes ID" },
  { id: 6, title: "Design Thinking Workshop", category: "Workshop", date: "29 Mei 2024 · Impact Hub Jogja", location: "Impact Hub Jogja", address: "Jl. Diponegoro 72, Jogja", price: "Rp50.000", distance: "3.1 km", image: "💡", color: "#3A1A1A", saved: false, desc: "Workshop intensif design thinking untuk mahasiswa dan fresh graduate.", organizer: "Impact Hub Jogja" },
  { id: 7, title: "Morning Run Community", category: "Olahraga", date: "26 Mei 2024 · 05.30 WIB", location: "GOR Among Raga", address: "Jl. Kenari, Yogyakarta", price: "Gratis", distance: "1.8 km", image: "🏃", color: "#1A3A1A", saved: false, desc: "Lari pagi bareng komunitas runner Jogja. Rute 5K dan 10K tersedia.", organizer: "Jogja Runners" },
  { id: 8, title: "Stand Up Comedy Show", category: "Konser", date: "30 Mei 2024", location: "Taman Budaya Yogyakarta", address: "Jl. Sri Wedani, Yogyakarta", price: "Rp85.000", distance: "2.2 km", image: "🎤", color: "#2A1A00", saved: false, desc: "Malam penuh tawa bersama komika-komika lokal dan nasional.", organizer: "Stand Up Indo Jogja" },
  { id: 9, title: "Street Art Tour Jogja", category: "Komunitas", date: "Sab, 18 Mei 2024 · 09.00 WIB", location: "Titik Nol Kilometer", address: "Jl. Margo Mulyo, Yogyakarta", price: "Gratis", distance: "0.8 km", image: "🎨", color: "#1A0A2E", saved: false, desc: "Tur seni jalanan keliling sudut-sudut Kota Jogja bersama seniman lokal.", organizer: "Jogja Street Art" },
];

const categories = ["Semua", "Konser", "Workshop", "Festival", "Komunitas", "Olahraga"];
const catIcons = { Konser: "🎵", Workshop: "💡", Festival: "🎪", Komunitas: "👥", Olahraga: "⚽" };
const catColors = { Konser: "#5C3BFE", Workshop: "#FF6B6B", Festival: "#F59E0B", Komunitas: "#10B981", Olahraga: "#3B82F6" };

function Badge({ cat }) {
  const color = catColors[cat] || COLORS.primary;
  return (
    <span style={{ background: color + "22", color, fontSize: 10, fontWeight: 700, padding: "2px 8px", borderRadius: 20, letterSpacing: 0.3 }}>
      {cat}
    </span>
  );
}

function EventCard({ event, onClick, onToggleSave, mini }) {
  return (
    <div onClick={() => onClick(event)} style={{
      background: COLORS.card,
      borderRadius: 16,
      overflow: "hidden",
      cursor: "pointer",
      boxShadow: "0 2px 12px rgba(92,59,254,0.08)",
      transition: "transform 0.18s, box-shadow 0.18s",
      minWidth: mini ? 160 : "auto",
      maxWidth: mini ? 175 : "auto",
      flexShrink: 0,
    }}
      onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-2px)"; e.currentTarget.style.boxShadow = "0 8px 24px rgba(92,59,254,0.15)"; }}
      onMouseLeave={e => { e.currentTarget.style.transform = ""; e.currentTarget.style.boxShadow = "0 2px 12px rgba(92,59,254,0.08)"; }}
    >
      <div style={{ background: event.color, height: mini ? 90 : 100, display: "flex", alignItems: "center", justifyContent: "center", fontSize: mini ? 32 : 40, position: "relative" }}>
        {event.image}
        <button onClick={e => { e.stopPropagation(); onToggleSave(event.id); }} style={{ position: "absolute", top: 8, right: 8, background: "rgba(255,255,255,0.2)", border: "none", borderRadius: 8, width: 28, height: 28, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", fontSize: 14 }}>
          {event.saved ? "🔖" : "🔖"}
        </button>
        <div style={{ position: "absolute", top: 8, left: 8 }}><Badge cat={event.category} /></div>
      </div>
      <div style={{ padding: mini ? "8px 10px" : "10px 12px" }}>
        <div style={{ fontWeight: 700, fontSize: mini ? 12 : 13, color: COLORS.text, marginBottom: 3, lineHeight: 1.3 }}>{event.title}</div>
        <div style={{ fontSize: 10, color: COLORS.textMuted, marginBottom: 2 }}>{event.date.split("·")[0]}</div>
        <div style={{ fontSize: 10, color: COLORS.textMuted }}>{event.location}</div>
      </div>
    </div>
  );
}

function NearbyCard({ event, onClick }) {
  return (
    <div onClick={() => onClick(event)} style={{ background: COLORS.card, borderRadius: 14, padding: "12px 14px", display: "flex", gap: 12, alignItems: "center", cursor: "pointer", boxShadow: "0 2px 8px rgba(92,59,254,0.06)", marginBottom: 10 }}>
      <div style={{ background: event.color, borderRadius: 12, width: 56, height: 56, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, flexShrink: 0 }}>{event.image}</div>
      <div style={{ flex: 1 }}>
        <Badge cat={event.category} />
        <div style={{ fontWeight: 700, fontSize: 13, color: COLORS.text, marginTop: 3 }}>{event.title}</div>
        <div style={{ fontSize: 11, color: COLORS.textMuted }}>{event.date}</div>
        <div style={{ fontSize: 11, color: COLORS.textMuted }}>{event.location}</div>
      </div>
      <div style={{ fontSize: 11, color: COLORS.primary, fontWeight: 700, background: COLORS.surface, padding: "4px 8px", borderRadius: 10 }}>📍 {event.distance}</div>
    </div>
  );
}

function HomeScreen({ events, onEventClick, onToggleSave, setActiveTab }) {
  const [search, setSearch] = useState("");
  const recommended = events.slice(0, 3);
  const nearby = events.filter(e => parseFloat(e.distance) < 3).slice(0, 1)[0];

  return (
    <div style={{ height: "100%", overflowY: "auto", paddingBottom: 80 }}>
      {/* Header */}
      <div style={{ padding: "16px 16px 8px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ fontSize: 18 }}>✦</span>
          <span style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 18, color: COLORS.primary, letterSpacing: -0.5 }}>HAPPENLY</span>
        </div>
        <div style={{ background: COLORS.surface, borderRadius: 10, padding: "6px 10px", cursor: "pointer", fontSize: 16 }}>🔔</div>
      </div>

      {/* Search */}
      <div style={{ padding: "0 16px 12px" }}>
        <div style={{ background: COLORS.card, border: `1.5px solid ${COLORS.surface}`, borderRadius: 14, display: "flex", alignItems: "center", padding: "10px 14px", gap: 8, boxShadow: "0 2px 8px rgba(92,59,254,0.06)" }}>
          <span style={{ color: COLORS.textMuted, fontSize: 16 }}>🔍</span>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Cari event, lokasi, atau kategori..." style={{ border: "none", outline: "none", flex: 1, fontSize: 13, color: COLORS.text, background: "transparent" }} />
          <div style={{ background: COLORS.primary, borderRadius: 8, width: 28, height: 28, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", fontSize: 14 }}>⚙️</div>
        </div>
      </div>

      {/* Rekomendasi */}
      <div style={{ padding: "0 16px 8px" }}>
        <div style={{ fontWeight: 800, fontSize: 15, color: COLORS.text, marginBottom: 10 }}>Rekomendasi Untukmu ✨</div>
        <div style={{ display: "flex", gap: 10, overflowX: "auto", paddingBottom: 4 }}>
          {recommended.map(e => (
            <EventCard key={e.id} event={e} onClick={onEventClick} onToggleSave={onToggleSave} mini />
          ))}
        </div>
      </div>

      {/* Event Terdekat */}
      <div style={{ padding: "8px 16px 8px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
          <div style={{ fontWeight: 800, fontSize: 15, color: COLORS.text }}>Event Terdekat 📍</div>
          <span onClick={() => setActiveTab("nearby")} style={{ fontSize: 12, color: COLORS.primary, fontWeight: 700, cursor: "pointer" }}>Lihat semua</span>
        </div>
        {nearby && (
          <div onClick={() => onEventClick(nearby)} style={{ background: nearby.color, borderRadius: 16, padding: "16px", cursor: "pointer", position: "relative", overflow: "hidden" }}>
            <div style={{ position: "absolute", top: 8, left: 10 }}><Badge cat={nearby.category} /></div>
            <div style={{ position: "absolute", top: 8, right: 10, background: "rgba(255,255,255,0.2)", borderRadius: 10, padding: "3px 8px", fontSize: 11, color: "#fff", fontWeight: 700 }}>📍 {nearby.distance}</div>
            <div style={{ marginTop: 24, fontSize: 36 }}>{nearby.image}</div>
            <div style={{ fontWeight: 800, fontSize: 16, color: "#fff", marginTop: 8 }}>{nearby.title}</div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.7)", marginTop: 2 }}>{nearby.date}</div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.7)" }}>{nearby.location}</div>
          </div>
        )}
      </div>

      {/* Kategori */}
      <div style={{ padding: "8px 16px 0" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
          <div style={{ fontWeight: 800, fontSize: 15, color: COLORS.text }}>Kategori</div>
          <span onClick={() => setActiveTab("explore")} style={{ fontSize: 12, color: COLORS.primary, fontWeight: 700, cursor: "pointer" }}>Lihat semua</span>
        </div>
        <div style={{ display: "flex", gap: 10, justifyContent: "space-between" }}>
          {categories.slice(1).map(cat => (
            <div key={cat} onClick={() => setActiveTab("explore")} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4, cursor: "pointer" }}>
              <div style={{ background: (catColors[cat] || COLORS.primary) + "18", borderRadius: 12, width: 44, height: 44, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 }}>{catIcons[cat]}</div>
              <span style={{ fontSize: 10, fontWeight: 600, color: COLORS.textMuted }}>{cat}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ExploreScreen({ events, onEventClick, onToggleSave }) {
  const [selectedCat, setSelectedCat] = useState("Semua");
  const [search, setSearch] = useState("");

  const filtered = events.filter(e => {
    const matchCat = selectedCat === "Semua" || e.category === selectedCat;
    const matchSearch = e.title.toLowerCase().includes(search.toLowerCase()) || e.location.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  return (
    <div style={{ height: "100%", overflowY: "auto", paddingBottom: 80 }}>
      <div style={{ padding: "16px 16px 8px", fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 18, color: COLORS.text }}>Explore</div>
      <div style={{ padding: "0 16px 10px" }}>
        <div style={{ background: COLORS.card, border: `1.5px solid ${COLORS.surface}`, borderRadius: 14, display: "flex", alignItems: "center", padding: "10px 14px", gap: 8 }}>
          <span style={{ color: COLORS.textMuted }}>🔍</span>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Cari event..." style={{ border: "none", outline: "none", flex: 1, fontSize: 13, background: "transparent" }} />
        </div>
      </div>
      <div style={{ display: "flex", gap: 8, overflowX: "auto", padding: "0 16px 12px" }}>
        {categories.map(cat => (
          <button key={cat} onClick={() => setSelectedCat(cat)} style={{ background: selectedCat === cat ? COLORS.primary : COLORS.surface, color: selectedCat === cat ? "#fff" : COLORS.textMuted, border: "none", borderRadius: 20, padding: "6px 14px", fontSize: 12, fontWeight: 700, cursor: "pointer", whiteSpace: "nowrap", transition: "all 0.2s" }}>{cat}</button>
        ))}
      </div>
      <div style={{ padding: "0 16px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        {filtered.map(e => (
          <EventCard key={e.id} event={e} onClick={onEventClick} onToggleSave={onToggleSave} />
        ))}
      </div>
      {filtered.length === 0 && (
        <div style={{ textAlign: "center", padding: "40px 20px", color: COLORS.textMuted }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>🔍</div>
          <div style={{ fontWeight: 700 }}>Event tidak ditemukan</div>
        </div>
      )}
    </div>
  );
}

function NearbyScreen({ events, onEventClick }) {
  const sorted = [...events].sort((a, b) => parseFloat(a.distance) - parseFloat(b.distance));
  return (
    <div style={{ height: "100%", overflowY: "auto", paddingBottom: 80 }}>
      <div style={{ padding: "16px 16px 6px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 18, color: COLORS.text }}>Nearby</div>
        <div style={{ background: COLORS.surface, borderRadius: 10, padding: "6px 12px", fontSize: 12, fontWeight: 700, color: COLORS.primary, cursor: "pointer" }}>Filter</div>
      </div>
      <div style={{ padding: "0 16px 10px" }}>
        <div style={{ background: COLORS.primary + "15", borderRadius: 14, padding: "10px 14px", display: "flex", alignItems: "center", gap: 8 }}>
          <span>📍</span>
          <span style={{ fontSize: 12, color: COLORS.primary, fontWeight: 600 }}>Tampilkan event di sekitar saya</span>
          <div style={{ marginLeft: "auto", background: COLORS.primary, borderRadius: 20, width: 36, height: 20, position: "relative", cursor: "pointer" }}>
            <div style={{ position: "absolute", right: 2, top: 2, width: 16, height: 16, background: "#fff", borderRadius: "50%" }} />
          </div>
        </div>
      </div>
      {/* Map placeholder */}
      <div style={{ margin: "0 16px 14px", background: "linear-gradient(135deg, #e8e3ff 0%, #d4c8ff 100%)", borderRadius: 16, height: 160, display: "flex", alignItems: "center", justifyContent: "center", position: "relative", overflow: "hidden" }}>
        <div style={{ fontSize: 13, color: COLORS.primary, fontWeight: 700, opacity: 0.6 }}>🗺️ Peta Interaktif</div>
        {sorted.slice(0, 3).map((e, i) => (
          <div key={e.id} onClick={() => {}} style={{ position: "absolute", top: `${25 + i * 25}%`, left: `${20 + i * 25}%`, background: COLORS.primary, borderRadius: "50%", width: 28, height: 28, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, cursor: "pointer", boxShadow: "0 2px 8px rgba(92,59,254,0.4)" }}>📍</div>
        ))}
      </div>
      <div style={{ padding: "0 16px" }}>
        {sorted.map(e => <NearbyCard key={e.id} event={e} onClick={onEventClick} />)}
      </div>
    </div>
  );
}

function ReminderScreen({ events }) {
  const [tab, setTab] = useState("upcoming");
  const upcoming = events.slice(0, 4);
  const done = events.slice(4, 6);

  return (
    <div style={{ height: "100%", overflowY: "auto", paddingBottom: 80 }}>
      <div style={{ padding: "16px 16px 10px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 18, color: COLORS.text }}>🔔 Reminder</div>
        <div style={{ background: COLORS.primary, borderRadius: 8, padding: "4px 10px", fontSize: 20, cursor: "pointer", color: "#fff" }}>+</div>
      </div>
      <div style={{ display: "flex", margin: "0 16px 14px", background: COLORS.surface, borderRadius: 12, padding: 4 }}>
        {["upcoming", "done"].map(t => (
          <button key={t} onClick={() => setTab(t)} style={{ flex: 1, background: tab === t ? COLORS.primary : "transparent", color: tab === t ? "#fff" : COLORS.textMuted, border: "none", borderRadius: 10, padding: "8px 0", fontSize: 12, fontWeight: 700, cursor: "pointer", transition: "all 0.2s" }}>
            {t === "upcoming" ? "Akan Datang" : "Selesai"}
          </button>
        ))}
      </div>
      <div style={{ padding: "0 16px" }}>
        {(tab === "upcoming" ? upcoming : done).map(e => (
          <div key={e.id} style={{ background: COLORS.card, borderRadius: 14, padding: "12px 14px", display: "flex", gap: 12, alignItems: "center", marginBottom: 10, boxShadow: "0 2px 8px rgba(92,59,254,0.06)" }}>
            <div style={{ background: e.color, borderRadius: 12, width: 52, height: 52, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, flexShrink: 0 }}>{e.image}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 700, fontSize: 13, color: COLORS.text }}>{e.title}</div>
              <div style={{ fontSize: 11, color: COLORS.textMuted }}>{e.date}</div>
              <div style={{ fontSize: 11, color: COLORS.textMuted }}>{e.location}</div>
            </div>
            <div style={{ fontSize: 10, color: COLORS.primary, fontWeight: 700, background: COLORS.surface, padding: "3px 8px", borderRadius: 8 }}>3 hari lagi</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function SavedScreen({ events, onEventClick, onToggleSave }) {
  const [tab, setTab] = useState("event");
  const saved = events.filter(e => e.saved);

  return (
    <div style={{ height: "100%", overflowY: "auto", paddingBottom: 80 }}>
      <div style={{ padding: "16px 16px 10px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 18, color: COLORS.text }}>Saved</div>
        <span style={{ fontSize: 18, cursor: "pointer" }}>🔖</span>
      </div>
      <div style={{ display: "flex", margin: "0 16px 14px", background: COLORS.surface, borderRadius: 12, padding: 4 }}>
        {["event", "org"].map(t => (
          <button key={t} onClick={() => setTab(t)} style={{ flex: 1, background: tab === t ? COLORS.primary : "transparent", color: tab === t ? "#fff" : COLORS.textMuted, border: "none", borderRadius: 10, padding: "8px 0", fontSize: 12, fontWeight: 700, cursor: "pointer" }}>
            {t === "event" ? "Event" : "Organisasi"}
          </button>
        ))}
      </div>
      {tab === "event" ? (
        <div style={{ padding: "0 16px" }}>
          {saved.length === 0 ? (
            <div style={{ textAlign: "center", padding: "40px 20px", color: COLORS.textMuted }}>
              <div style={{ fontSize: 40, marginBottom: 12 }}>🔖</div>
              <div style={{ fontWeight: 700 }}>Belum ada event tersimpan</div>
              <div style={{ fontSize: 12, marginTop: 4 }}>Simpan event favoritmu agar tidak terlewat!</div>
            </div>
          ) : saved.map(e => <NearbyCard key={e.id} event={e} onClick={onEventClick} />)}
        </div>
      ) : (
        <div style={{ padding: "0 16px" }}>
          {["Jogja Runners", "Komunitas Foto Jogja", "Stand Up Indo Jogja"].map(org => (
            <div key={org} style={{ background: COLORS.card, borderRadius: 14, padding: "12px 14px", display: "flex", gap: 10, alignItems: "center", marginBottom: 10 }}>
              <div style={{ width: 44, height: 44, background: COLORS.surface, borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22 }}>👥</div>
              <div>
                <div style={{ fontWeight: 700, fontSize: 13 }}>{org}</div>
                <div style={{ fontSize: 11, color: COLORS.textMuted }}>Komunitas Lokal · Jogja</div>
              </div>
              <div style={{ marginLeft: "auto", background: COLORS.surface, borderRadius: 8, padding: "4px 10px", fontSize: 11, color: COLORS.primary, fontWeight: 700 }}>Ikuti</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function UploadScreen({ onClose }) {
  const [form, setForm] = useState({ name: "", category: "", date: "", location: "" });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = () => {
    if (form.name && form.category) setSubmitted(true);
  };

  return (
    <div style={{ height: "100%", overflowY: "auto", paddingBottom: 80 }}>
      <div style={{ padding: "16px 16px 10px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 18, color: COLORS.text }}>Buat Event</div>
        <div onClick={onClose} style={{ cursor: "pointer", fontSize: 18, color: COLORS.textMuted }}>✕</div>
      </div>
      {submitted ? (
        <div style={{ padding: "40px 20px", textAlign: "center" }}>
          <div style={{ fontSize: 60, marginBottom: 16 }}>🎉</div>
          <div style={{ fontWeight: 800, fontSize: 18, color: COLORS.text }}>Event Berhasil Dikirim!</div>
          <div style={{ fontSize: 13, color: COLORS.textMuted, marginTop: 8 }}>Event kamu sedang dalam review dan akan segera tampil di platform.</div>
          <button onClick={() => { setSubmitted(false); setForm({ name: "", category: "", date: "", location: "" }); onClose(); }} style={{ marginTop: 24, background: COLORS.primary, color: "#fff", border: "none", borderRadius: 14, padding: "12px 32px", fontWeight: 800, fontSize: 14, cursor: "pointer" }}>Kembali ke Home</button>
        </div>
      ) : (
        <div style={{ padding: "0 16px" }}>
          <div style={{ background: COLORS.surface, borderRadius: 16, height: 120, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", marginBottom: 16, cursor: "pointer", border: `2px dashed ${COLORS.primary}44` }}>
            <div style={{ fontSize: 28 }}>🖼️</div>
            <div style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 6 }}>Upload Poster / Foto</div>
          </div>
          {[
            { key: "name", label: "Nama Event", placeholder: "Contoh: Workshop Creative Branding" },
            { key: "category", label: "Kategori", placeholder: "Pilih kategori" },
            { key: "date", label: "Tanggal & Waktu", placeholder: "Pilih tanggal & waktu" },
            { key: "location", label: "Lokasi", placeholder: "Masukkan lokasi event" },
          ].map(f => (
            <div key={f.key} style={{ marginBottom: 14 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: COLORS.text, marginBottom: 6 }}>{f.label}</div>
              <input value={form[f.key]} onChange={e => setForm({ ...form, [f.key]: e.target.value })} placeholder={f.placeholder} style={{ width: "100%", background: COLORS.surface, border: "none", borderRadius: 12, padding: "12px 14px", fontSize: 13, color: COLORS.text, outline: "none", boxSizing: "border-box" }} />
            </div>
          ))}
          <div style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: COLORS.text, marginBottom: 6 }}>Deskripsi Event</div>
            <textarea placeholder="Ceritakan tentang event kamu..." rows={3} style={{ width: "100%", background: COLORS.surface, border: "none", borderRadius: 12, padding: "12px 14px", fontSize: 13, color: COLORS.text, outline: "none", resize: "none", boxSizing: "border-box" }} />
          </div>
          <button onClick={handleSubmit} style={{ width: "100%", background: COLORS.primary, color: "#fff", border: "none", borderRadius: 14, padding: "14px", fontWeight: 800, fontSize: 14, cursor: "pointer", marginBottom: 8, transition: "opacity 0.2s" }}
            onMouseEnter={e => e.target.style.opacity = "0.9"} onMouseLeave={e => e.target.style.opacity = "1"}>
            🚀 Publikasikan Event
          </button>
        </div>
      )}
    </div>
  );
}

function EventDetail({ event, onBack, onToggleSave }) {
  if (!event) return null;
  return (
    <div style={{ height: "100%", overflowY: "auto", background: COLORS.bg }}>
      <div style={{ background: event.color, height: 220, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 80, position: "relative" }}>
        {event.image}
        <button onClick={onBack} style={{ position: "absolute", top: 16, left: 16, background: "rgba(255,255,255,0.2)", border: "none", borderRadius: 10, padding: "8px 12px", cursor: "pointer", fontSize: 16, color: "#fff" }}>←</button>
        <button onClick={() => onToggleSave(event.id)} style={{ position: "absolute", top: 16, right: 50, background: "rgba(255,255,255,0.2)", border: "none", borderRadius: 10, padding: "8px 10px", cursor: "pointer", fontSize: 16 }}>{event.saved ? "❤️" : "🤍"}</button>
        <button style={{ position: "absolute", top: 16, right: 16, background: "rgba(255,255,255,0.2)", border: "none", borderRadius: 10, padding: "8px 10px", cursor: "pointer", fontSize: 16 }}>↗️</button>
      </div>
      <div style={{ background: COLORS.card, borderRadius: "20px 20px 0 0", marginTop: -20, padding: "20px 20px 100px" }}>
        <Badge cat={event.category} />
        <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 22, color: COLORS.text, marginTop: 8, lineHeight: 1.2 }}>{event.title}</div>
        <div style={{ fontSize: 13, color: COLORS.textMuted, marginBottom: 20 }}>{event.organizer}</div>
        {[
          { icon: "📅", main: event.date, sub: null },
          { icon: "📍", main: event.location, sub: event.address, right: `📍 ${event.distance}` },
          { icon: "💰", main: `Mulai dari ${event.price}`, sub: null },
        ].map((item, i) => (
          <div key={i} style={{ display: "flex", gap: 12, alignItems: "flex-start", marginBottom: 14 }}>
            <div style={{ background: COLORS.surface, borderRadius: 10, width: 36, height: 36, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0 }}>{item.icon}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: COLORS.text }}>{item.main}</div>
              {item.sub && <div style={{ fontSize: 11, color: COLORS.textMuted }}>{item.sub}</div>}
            </div>
            {item.right && <div style={{ fontSize: 11, color: COLORS.primary, fontWeight: 700, background: COLORS.surface, padding: "3px 8px", borderRadius: 8 }}>{item.right}</div>}
          </div>
        ))}
        <div style={{ borderTop: `1px solid ${COLORS.surface}`, paddingTop: 16, marginTop: 4 }}>
          <div style={{ fontWeight: 800, fontSize: 14, color: COLORS.text, marginBottom: 8 }}>Tentang Event</div>
          <div style={{ fontSize: 13, color: COLORS.textMuted, lineHeight: 1.6 }}>{event.desc}</div>
          <div style={{ fontSize: 13, color: COLORS.primary, fontWeight: 700, marginTop: 8, cursor: "pointer" }}>Lihat selengkapnya ∨</div>
        </div>
      </div>
      <div style={{ position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 390, background: COLORS.card, padding: "12px 20px", borderTop: `1px solid ${COLORS.surface}`, display: "flex", gap: 10 }}>
        <button style={{ flex: 1, background: COLORS.primary, color: "#fff", border: "none", borderRadius: 14, padding: "14px", fontWeight: 800, fontSize: 14, cursor: "pointer" }}>🎟️ Dapatkan Tiket</button>
        <button onClick={() => onToggleSave(event.id)} style={{ background: event.saved ? COLORS.primary : COLORS.surface, color: event.saved ? "#fff" : COLORS.primary, border: "none", borderRadius: 14, padding: "14px 16px", fontWeight: 800, cursor: "pointer", fontSize: 16 }}>🔖</button>
      </div>
    </div>
  );
}

function ProfileScreen() {
  return (
    <div style={{ height: "100%", overflowY: "auto", paddingBottom: 80 }}>
      <div style={{ padding: "16px", fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 18, color: COLORS.text }}>Profil</div>
      <div style={{ padding: "0 16px 20px", display: "flex", alignItems: "center", gap: 14 }}>
        <div style={{ width: 60, height: 60, background: "linear-gradient(135deg, #5C3BFE, #FF6B6B)", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28 }}>👤</div>
        <div>
          <div style={{ fontWeight: 800, fontSize: 16, color: COLORS.text }}>Finda Maharani</div>
          <div style={{ fontSize: 12, color: COLORS.textMuted }}>@finda_mhr · Jogja</div>
          <div style={{ marginTop: 4 }}><Badge cat="Komunitas" /></div>
        </div>
        <button style={{ marginLeft: "auto", background: COLORS.surface, border: "none", borderRadius: 10, padding: "8px 14px", fontSize: 12, color: COLORS.primary, fontWeight: 700, cursor: "pointer" }}>Edit Profil</button>
      </div>
      <div style={{ display: "flex", margin: "0 16px 20px", gap: 1, background: COLORS.surface, borderRadius: 14, overflow: "hidden" }}>
        {[["12", "Event Diikuti"], ["5", "Event Disimpan"], ["3", "Event Dibuat"]].map(([n, l]) => (
          <div key={l} style={{ flex: 1, padding: "14px 0", textAlign: "center", background: COLORS.card }}>
            <div style={{ fontWeight: 800, fontSize: 18, color: COLORS.primary }}>{n}</div>
            <div style={{ fontSize: 10, color: COLORS.textMuted }}>{l}</div>
          </div>
        ))}
      </div>
      {["Minat Saya", "Riwayat Event", "Pengaturan", "Notifikasi", "Bantuan", "Keluar"].map(item => (
        <div key={item} style={{ display: "flex", alignItems: "center", padding: "14px 20px", borderBottom: `1px solid ${COLORS.surface}`, cursor: "pointer" }}>
          <span style={{ fontSize: 13, fontWeight: item === "Keluar" ? 700 : 600, color: item === "Keluar" ? COLORS.accent : COLORS.text }}>{item === "Keluar" ? "🚪 " : "→ "}{item}</span>
          {item !== "Keluar" && <span style={{ marginLeft: "auto", color: COLORS.textMuted, fontSize: 16 }}>›</span>}
        </div>
      ))}
    </div>
  );
}

export default function Happenly() {
  const [eventsData, setEventsData] = useState(events);
  const [activeTab, setActiveTab] = useState("home");
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [showUpload, setShowUpload] = useState(false);

  const toggleSave = (id) => {
    setEventsData(prev => prev.map(e => e.id === id ? { ...e, saved: !e.saved } : e));
    if (selectedEvent?.id === id) setSelectedEvent(prev => ({ ...prev, saved: !prev.saved }));
  };

  const handleEventClick = (event) => setSelectedEvent(event);
  const handleBack = () => setSelectedEvent(null);

  const tabs = [
    { id: "home", icon: "🏠", label: "Home" },
    { id: "explore", icon: "🔍", label: "Explore" },
    { id: "add", icon: "➕", label: "" },
    { id: "saved", icon: "🔖", label: "Saved" },
    { id: "profile", icon: "👤", label: "Profile" },
  ];

  const renderScreen = () => {
    if (showUpload) return <UploadScreen onClose={() => setShowUpload(false)} />;
    if (selectedEvent) return <EventDetail event={eventsData.find(e => e.id === selectedEvent.id)} onBack={handleBack} onToggleSave={toggleSave} />;
    switch (activeTab) {
      case "home": return <HomeScreen events={eventsData} onEventClick={handleEventClick} onToggleSave={toggleSave} setActiveTab={setActiveTab} />;
      case "explore": return <ExploreScreen events={eventsData} onEventClick={handleEventClick} onToggleSave={toggleSave} />;
      case "nearby": return <NearbyScreen events={eventsData} onEventClick={handleEventClick} />;
      case "reminder": return <ReminderScreen events={eventsData} />;
      case "saved": return <SavedScreen events={eventsData} onEventClick={handleEventClick} onToggleSave={toggleSave} />;
      case "profile": return <ProfileScreen />;
      default: return null;
    }
  };

  return (
    <div style={{ minHeight: "100vh", background: "#E8E3FF", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Plus Jakarta Sans', 'Segoe UI', sans-serif", padding: "20px 0" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap');
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 0; height: 0; }
      `}</style>
      <div style={{ width: 390, height: 844, background: COLORS.bg, borderRadius: 44, overflow: "hidden", boxShadow: "0 30px 80px rgba(92,59,254,0.3), 0 0 0 8px #fff, 0 0 0 10px rgba(92,59,254,0.15)", position: "relative", display: "flex", flexDirection: "column" }}>
        {/* Status bar */}
        <div style={{ background: COLORS.bg, padding: "14px 28px 0", display: "flex", justifyContent: "space-between", alignItems: "center", flexShrink: 0 }}>
          <span style={{ fontSize: 12, fontWeight: 700, color: COLORS.text }}>9:41</span>
          <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
            <span style={{ fontSize: 11 }}>📶</span>
            <span style={{ fontSize: 11 }}>📡</span>
            <span style={{ fontSize: 11 }}>🔋</span>
          </div>
        </div>

        {/* Content */}
        <div style={{ flex: 1, overflow: "hidden", position: "relative" }}>
          {renderScreen()}
        </div>

        {/* Bottom nav */}
        {!selectedEvent && !showUpload && (
          <div style={{ background: COLORS.card, borderTop: `1px solid ${COLORS.surface}`, padding: "8px 20px 20px", display: "flex", justifyContent: "space-between", alignItems: "center", flexShrink: 0 }}>
            {tabs.map(tab => (
              tab.id === "add" ? (
                <button key="add" onClick={() => setShowUpload(true)} style={{ background: COLORS.primary, border: "none", borderRadius: 20, width: 52, height: 52, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, cursor: "pointer", boxShadow: "0 4px 16px rgba(92,59,254,0.4)", transform: "translateY(-4px)", transition: "all 0.2s" }}>
                  <span style={{ color: "#fff", fontSize: 22, fontWeight: 700 }}>+</span>
                </button>
              ) : (
                <button key={tab.id} onClick={() => { setSelectedEvent(null); setActiveTab(tab.id); }} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3, background: "none", border: "none", cursor: "pointer", padding: "4px 8px" }}>
                  <span style={{ fontSize: 20, opacity: activeTab === tab.id ? 1 : 0.4, filter: activeTab === tab.id ? "none" : "grayscale(1)" }}>{tab.icon}</span>
                  <span style={{ fontSize: 10, fontWeight: 700, color: activeTab === tab.id ? COLORS.primary : COLORS.textMuted }}>{tab.label}</span>
                  {activeTab === tab.id && <div style={{ width: 4, height: 4, background: COLORS.primary, borderRadius: "50%" }} />}
                </button>
              )
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
