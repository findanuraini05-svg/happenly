# ✦ HAPPENLY — Event Discovery Platform

Platform untuk menemukan konser, festival, workshop, volunteer, dan event komunitas dalam satu tempat.

---

## 🚀 Cara Deploy ke Vercel (Tanpa Coding!)

### Metode 1 — Via GitHub + Vercel (Recommended)

1. **Upload ke GitHub**
   - Buka [github.com](https://github.com) → login atau daftar
   - Klik tombol **"New repository"** (tombol hijau)
   - Nama repo: `happenly`
   - Klik **"Create repository"**
   - Upload semua file ini dengan klik **"uploading an existing file"**
   - Drag semua file & folder → klik **"Commit changes"**

2. **Deploy ke Vercel**
   - Buka [vercel.com](https://vercel.com) → login dengan akun GitHub
   - Klik **"Add New Project"**
   - Pilih repository `happenly`
   - Klik **"Deploy"** — tunggu ~1 menit
   - ✅ Selesai! Dapat link seperti: `happenly.vercel.app`

---

### Metode 2 — Via Vercel CLI (Perlu Node.js)

```bash
# Install dependencies
npm install

# Test di lokal dulu
npm run dev

# Deploy ke Vercel
npx vercel --prod
```

---

## 📱 Fitur Aplikasi

- 🏠 **Home** — Rekomendasi & event terdekat
- 🔍 **Explore** — Filter berdasarkan kategori
- 📍 **Nearby** — Event di sekitar lokasi
- 🔔 **Reminder** — Pengingat event favorit
- 🔖 **Saved** — Simpan event & organisasi
- ➕ **Upload Event** — Buat & bagikan event komunitas

---

## 🛠 Tech Stack

- React 18
- Vite 5
- Pure CSS-in-JS (no external UI library)
- Google Fonts (Syne + Plus Jakarta Sans)

---

Made with ❤️ by HAPPENLY Team
